import numpy as np
from scipy.stats import genextreme

def q(theta, y, x): 
    '''q: Criterion function, passed to estimation.estimate().
    '''
    return -loglikelihood(theta, y, x)


def loglikelihood(theta, y, x): 
    '''loglikelihood()
    Args. 
        theta: (K,) vector of parameters 
        x: (N,J,K) matrix of covariates 
        y: (N,J) matrix of market shares
    
    Returns
        ll_i: (N,) vector of loglikelihood contributions
    '''
    assert theta.ndim == 1 
    N,J,K = x.shape 

    log_s = log_cont(theta,x)
    #s += 1e-10
    #log_s = np.log(s)

    prod = y*log_s
    ll_i = np.sum(prod,axis=1, keepdims=True).flatten()


    return ll_i 

def choice_prob(theta, x):
    '''choice_prob(): Computes the (N,J) matrix of choice probabilities 
    Args. 
        theta: (K,) vector of parameters 
        x: (N,J,K) matrix of covariates 
    
    Returns
        ccp: (N,J) matrix of probabilities 
    '''
    assert theta.ndim == 1, f'theta should have ndim == 1, got {theta.ndim}'
    N, J, K = x.shape
    
    # deterministic utility 
    v = (x @ theta).astype(np.float64)
    v -= v.max(axis=1, keepdims=True) # max rescale
    
    # denominator 
    denom = np.exp(v).sum(axis=1, keepdims=True) # (N,1)
    
    # Conditional choice probabilites
    ccp = np.exp(v) / denom

    return ccp

    
def log_cont(theta, x):
    '''choice_prob(): Computes the (N,J) matrix of log-likelihood contributions
    Args. 
        theta: (K,) vector of parameters 
        x: (N,J,K) matrix of covariates 
    
    Returns
        ccp: (N,J) matrix of contributions
    '''
    assert theta.ndim == 1, f'theta should have ndim == 1, got {theta.ndim}'
    N, J, K = x.shape
    
    # deterministic utility 
    v = (x @ theta).astype(np.float64)
    v -= v.max(axis=1, keepdims=True) # max rescale
    
    # denominator 
    denom = np.exp(v).sum(axis=1, keepdims=True) # (N,1)
    
    # Conditional choice probabilites
    # ccp = np.exp(v) / denom
    
    log_s = v - np.log(denom)

    return log_s



